import { useState, type ReactNode } from "react";
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export interface ComboboxOption {
  value: string;
  label: string;
  sublabel?: string;
}

/**
 * Ação fixa exibida abaixo da lista — não rola junto com os items e não é
 * afetada pelo filtro de busca. Tipicamente usada para "Criar novo X"
 * mantendo destaque visual de ação primária (cor `--primary` do DS).
 */
export interface ComboboxPinnedAction {
  label: string;
  sublabel?: string;
  icon?: ReactNode;
  onSelect: () => void;
}

interface ComboboxProps {
  options: ComboboxOption[];
  value: string;
  onValueChange: (value: string) => void;
  placeholder?: string;
  searchPlaceholder?: string;
  emptyText?: string;
  disabled?: boolean;
  className?: string;
  /**
   * Ação fixa no rodapé do dropdown (não rola, não é filtrada pela busca).
   * Destacada com o token `--primary` para sinalizar ação primária — comum
   * para "Criar novo registro" diretamente do combobox.
   */
  pinnedAction?: ComboboxPinnedAction;
}

export function Combobox({
  options,
  value,
  onValueChange,
  placeholder = "Selecionar...",
  searchPlaceholder = "Buscar...",
  emptyText = "Nenhum resultado encontrado.",
  disabled = false,
  className,
  pinnedAction,
}: ComboboxProps) {
  const [open, setOpen] = useState(false);
  const selected = options.find((opt) => opt.value === value);

  const handlePinnedAction = () => {
    pinnedAction?.onSelect();
    setOpen(false);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          disabled={disabled}
          className={cn(
            "w-full justify-between bg-card border-border text-foreground font-normal h-9 px-3",
            !selected && "text-muted-foreground",
            disabled && "opacity-50 cursor-not-allowed",
            className
          )}
        >
          <span className="truncate text-sm">
            {selected ? selected.label : placeholder}
          </span>
          <ChevronsUpDown className="ml-2 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
        </Button>
      </PopoverTrigger>
      <PopoverContent
        className="w-[--radix-popover-trigger-width] p-0 bg-card border-border shadow-md"
        align="start"
        sideOffset={4}
      >
        <Command className="bg-card">
          <CommandInput
            placeholder={searchPlaceholder}
            className="h-9 text-foreground placeholder:text-muted-foreground text-sm"
          />
          <CommandList>
            <CommandEmpty className="py-5 text-center text-sm text-muted-foreground">
              {emptyText}
            </CommandEmpty>
            <CommandGroup>
              {options.map((opt) => (
                <CommandItem
                  key={opt.value}
                  value={opt.label}
                  onSelect={() => {
                    onValueChange(opt.value === value ? "" : opt.value);
                    setOpen(false);
                  }}
                  className="cursor-pointer text-foreground data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground group"
                >
                  <div className="flex flex-col gap-0.5 flex-1 min-w-0">
                    <span className="text-sm">{opt.label}</span>
                    {opt.sublabel && (
                      <span className="text-xs text-muted-foreground leading-none group-data-[selected=true]:text-accent-foreground/80">
                        {opt.sublabel}
                      </span>
                    )}
                  </div>
                  <Check
                    className={cn(
                      "ml-2 h-4 w-4 shrink-0 text-primary",
                      value === opt.value ? "opacity-100" : "opacity-0"
                    )}
                  />
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>

          {/* Ação fixa no rodapé — destaque de ação primária. Fica fora do
              CommandList para não rolar com a lista e não ser filtrada pela
              busca do CommandInput. */}
          {pinnedAction && (
            <button
              type="button"
              onClick={handlePinnedAction}
              className="flex w-full items-center gap-2 border-t border-border bg-primary/10 px-3 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground focus:outline-none"
            >
              {pinnedAction.icon}
              <div className="flex flex-col gap-0.5 flex-1 min-w-0 text-left">
                <span className="text-sm font-semibold leading-tight">
                  {pinnedAction.label}
                </span>
                {pinnedAction.sublabel && (
                  <span className="text-xs opacity-80 leading-tight">
                    {pinnedAction.sublabel}
                  </span>
                )}
              </div>
            </button>
          )}
        </Command>
      </PopoverContent>
    </Popover>
  );
}
