import { KeyboardEvent, useState } from "react";
import { X, Mail } from "lucide-react";
import { Input } from "@/components/ui/input";

interface MultiTagInputProps {
  values: string[];
  onChange: (next: string[]) => void;
  placeholder?: string;
  /** Caracter usado para separar os e-mails ao colar/digitar (default ";") */
  separator?: string;
  type?: "email" | "text";
  id?: string;
  /** Mostra o ícone de envelope dentro de cada chip (default true para email) */
  showIcon?: boolean;
}

/**
 * Input estilo "tag" — converte cada valor terminado por separator (default ";"),
 * Enter ou blur em uma chip removível. Visual aprimorado: chips com ícone de
 * envelope, cor primary suave e botão de remoção destacado.
 */
export function MultiTagInput({
  values,
  onChange,
  placeholder = "Digite e pressione ; ou Enter",
  separator = ";",
  type = "email",
  id,
  showIcon,
}: MultiTagInputProps) {
  const [draft, setDraft] = useState("");
  const withIcon = showIcon ?? type === "email";

  const commit = (raw: string) => {
    const parts = raw
      .split(separator)
      .map((p) => p.trim())
      .filter((p) => p.length > 0);
    if (parts.length === 0) return;
    const merged = Array.from(new Set([...values, ...parts]));
    onChange(merged);
    setDraft("");
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === separator || e.key === "Enter" || e.key === "Tab") {
      if (draft.trim()) {
        e.preventDefault();
        commit(draft);
      }
    } else if (e.key === "Backspace" && draft === "" && values.length > 0) {
      e.preventDefault();
      onChange(values.slice(0, -1));
    }
  };

  const removeAt = (idx: number) => {
    onChange(values.filter((_, i) => i !== idx));
  };

  return (
    <div className="rounded-md border border-input bg-background px-2 py-1.5 flex flex-wrap items-center gap-1.5 min-h-10 focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2 focus-within:ring-offset-background transition-shadow">
      {values.map((v, idx) => (
        <span
          key={`${v}-${idx}`}
          className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 text-primary pl-2 pr-1 py-0.5 text-xs font-body font-medium max-w-full"
        >
          {withIcon && <Mail className="h-3 w-3 shrink-0 opacity-80" />}
          <span className="truncate max-w-[220px]" title={v}>
            {v}
          </span>
          <button
            type="button"
            aria-label={`Remover ${v}`}
            onClick={() => removeAt(idx)}
            className="rounded-full p-0.5 hover:bg-destructive/20 hover:text-destructive transition-colors shrink-0"
          >
            <X className="h-3 w-3" />
          </button>
        </span>
      ))}
      <Input
        id={id}
        type={type}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={() => draft.trim() && commit(draft)}
        placeholder={values.length === 0 ? placeholder : ""}
        className="border-0 shadow-none focus-visible:ring-0 focus-visible:ring-offset-0 h-7 px-1 flex-1 min-w-[160px] bg-transparent"
      />
    </div>
  );
}
