import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationEllipsis,
} from "@/components/ui/pagination";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

/**
 * TablePagination — rodapé de paginação para tabelas.
 *
 * Composta sobre os primitivos de `Pagination` do design system:
 *   Pagination → PaginationContent → PaginationItem → (Button | PaginationEllipsis)
 *
 * Usa `Button` para as ações (não links), pois é paginação interna de tabela,
 * não navegação por URL.
 */
interface TablePaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  totalItems: number;
  itemsPerPage: number;
  /** Rótulo do tipo de item exibido no contador (padrão: "itens") */
  itemLabel?: string;
  className?: string;
  /** Mostra um seletor de itens por página (10/20/30/50/100). Quando habilitado,
   *  `onPageSizeChange` deve ser passado para receber a escolha do usuário. */
  pageSizeOptions?: number[];
  onPageSizeChange?: (size: number) => void;
}

export function TablePagination({
  currentPage,
  totalPages,
  onPageChange,
  totalItems,
  itemsPerPage,
  itemLabel = "itens",
  className,
  pageSizeOptions,
  onPageSizeChange,
}: TablePaginationProps) {
  if (totalItems === 0) return null;

  const start = (currentPage - 1) * itemsPerPage + 1;
  const end = Math.min(currentPage * itemsPerPage, totalItems);

  // Constrói a lista de páginas com reticências quando necessário
  const getPages = (): (number | "...")[] => {
    if (totalPages <= 7) return Array.from({ length: totalPages }, (_, i) => i + 1);
    const pages: (number | "...")[] = [1];
    if (currentPage > 3) pages.push("...");
    for (let p = Math.max(2, currentPage - 1); p <= Math.min(totalPages - 1, currentPage + 1); p++) {
      pages.push(p);
    }
    if (currentPage < totalPages - 2) pages.push("...");
    pages.push(totalPages);
    return pages;
  };

  return (
    <div className={cn("flex items-center justify-between gap-3 px-4 py-3 border-t border-border bg-card", className)}>
      {/* Contador + seletor de page size (opcional) */}
      <div className="flex items-center gap-3">
        <span className="text-xs text-muted-foreground">
          {`${start}–${end} de ${totalItems} ${itemLabel}`}
        </span>
        {pageSizeOptions && onPageSizeChange && (
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-muted-foreground">Itens por página</span>
            <Select
              value={String(itemsPerPage)}
              onValueChange={(v) => onPageSizeChange(Number(v))}
            >
              <SelectTrigger className="h-8 w-[72px] text-xs font-heading">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {pageSizeOptions.map((opt) => (
                  <SelectItem key={opt} value={String(opt)} className="text-xs">
                    {opt}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      {/* Controles de navegação — compostos sobre Pagination primitives */}
      <Pagination className="mx-0 w-auto justify-end">
        <PaginationContent className="gap-1">

          {/* Anterior */}
          <PaginationItem>
            <Button
              variant="outline"
              size="sm"
              className="h-8 px-3 text-xs font-heading gap-1"
              onClick={() => onPageChange(currentPage - 1)}
              disabled={currentPage === 1}
            >
              <ChevronLeft className="h-3.5 w-3.5" />
              Anterior
            </Button>
          </PaginationItem>

          {/* Números de página — sempre visíveis */}
          {getPages().map((page, idx) =>
            page === "..." ? (
              <PaginationItem key={`ellipsis-${idx}`}>
                <PaginationEllipsis className="h-8 w-8 text-xs" />
              </PaginationItem>
            ) : (
              <PaginationItem key={page}>
                <Button
                  variant={currentPage === page ? "default" : "outline"}
                  size="sm"
                  className={cn(
                    "h-8 w-8 text-xs font-heading p-0",
                    currentPage === page && "bg-primary text-primary-foreground hover:bg-primary/90"
                  )}
                  onClick={() => onPageChange(page as number)}
                >
                  {page}
                </Button>
              </PaginationItem>
            )
          )}

          {/* Próximo */}
          <PaginationItem>
            <Button
              variant="outline"
              size="sm"
              className="h-8 px-3 text-xs font-heading gap-1"
              onClick={() => onPageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              Próximo
              <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </PaginationItem>

        </PaginationContent>
      </Pagination>
    </div>
  );
}
