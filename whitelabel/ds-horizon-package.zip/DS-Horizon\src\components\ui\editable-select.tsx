import { forwardRef, useState, type KeyboardEvent } from "react";
import { ChevronDown, Plus, Trash2, Check, X } from "lucide-react";
import { toast } from "sonner";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

/* ─────────────────────────────────────────────────────────────────────────
 * EditableSelect — dropdown estilo "Grupo Familiar"
 *
 * Estrutura:
 *   ┌────────────────────────────┐
 *   │ Família Silva              │  ← seleção atual
 *   │ Família Ferreira           │     trash on hover → confirm dialog
 *   │ Hurricane                  │
 *   ├────────────────────────────┤
 *   │ + Criar novo grupo familiar│  ← ação (vira <input> inline ao clicar)
 *   └────────────────────────────┘
 *
 * Props:
 *   - options       : lista atual
 *   - value         : valor selecionado (single) ou array (multi)
 *   - onValueChange : callback de seleção
 *   - onCreateOption: chamado quando o usuário cria um item novo (pai persiste)
 *   - onDeleteOption: chamado após confirmação do dialog
 *   - createLabel   : texto do botão "+ Criar novo X"
 *   - itemLabel     : usado no dialog ("Excluir <itemLabel> X?")
 *   - placeholder   : texto quando vazio
 *
 * Acessibilidade: trigger é botão com role="combobox", listbox usa <ul>/<li>,
 * ações de excluir/criar são <button>s com aria-labels descritivos.
 * ───────────────────────────────────────────────────────────────────────── */

interface EditableSelectBaseProps {
  options: string[];
  onCreateOption: (name: string, flag?: boolean) => void;
  onDeleteOption: (name: string) => void;
  placeholder?: string;
  createLabel?: string;
  itemLabel?: string;
  disabled?: boolean;
  className?: string;
  /** Capitalização aplicada ao criar item (default: "preserve"). */
  createCase?: "upper" | "lower" | "title" | "preserve";
  /** Quando true, exibe um campo de busca no topo do popover. */
  searchable?: boolean;
  /**
   * Quando definido, exibe um switch ao lado do input de criação com este label.
   * O estado do switch é passado como segundo argumento de `onCreateOption`.
   */
  createFlagLabel?: string;
}

interface EditableSelectProps extends EditableSelectBaseProps {
  value: string;
  onValueChange: (value: string) => void;
}

interface EditableMultiSelectProps extends EditableSelectBaseProps {
  values: string[];
  onChange: (next: string[]) => void;
}

/* ─── Helpers compartilhados ──────────────────────────────────────────── */

function applyCase(s: string, mode: EditableSelectBaseProps["createCase"]): string {
  if (mode === "upper") return s.toUpperCase();
  if (mode === "lower") return s.toLowerCase();
  if (mode === "title") {
    return s
      .split(/\s+/)
      .map((w) => (w ? w[0].toUpperCase() + w.slice(1).toLowerCase() : w))
      .join(" ");
  }
  return s;
}

interface ListBodyProps {
  options: string[];
  selected: (opt: string) => boolean;
  onPick: (opt: string) => void;
  onAskDelete: (opt: string) => void;
  multiselect: boolean;
  creating: boolean;
  setCreating: (v: boolean) => void;
  draft: string;
  setDraft: (v: string) => void;
  onCreateAttempt: () => void;
  createLabel: string;
  /** Quando true, exibe input de busca no topo. */
  searchable?: boolean;
  searchValue?: string;
  onSearchChange?: (v: string) => void;
  /** Quando definido, exibe um switch abaixo do input de criação. */
  createFlagLabel?: string;
  createFlag?: boolean;
  onCreateFlagChange?: (v: boolean) => void;
}

function ListBody({
  options,
  selected,
  onPick,
  onAskDelete,
  multiselect,
  creating,
  setCreating,
  draft,
  setDraft,
  onCreateAttempt,
  createLabel,
  searchable,
  searchValue,
  onSearchChange,
  createFlagLabel,
  createFlag,
  onCreateFlagChange,
}: ListBodyProps) {
  const handleDraftKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      onCreateAttempt();
    } else if (e.key === "Escape") {
      e.preventDefault();
      setCreating(false);
      setDraft("");
    }
  };

  const filteredOptions = searchable && searchValue?.trim()
    ? options.filter((o) => o.toLowerCase().includes(searchValue.trim().toLowerCase()))
    : options;

  return (
    <>
      {searchable && (
        <div className="p-2 border-b border-border">
          <Input
            value={searchValue ?? ""}
            onChange={(e) => onSearchChange?.(e.target.value)}
            placeholder="Buscar…"
            className="h-8 text-sm"
            autoFocus
          />
        </div>
      )}
      {filteredOptions.length > 0 ? (
        <ul className="max-h-60 overflow-auto py-1">
          {filteredOptions.map((opt) => {
            const isSelected = selected(opt);
            return (
              <li key={opt}>
                <div
                  role="option"
                  aria-selected={isSelected}
                  className={cn(
                    "group flex items-center justify-between gap-2 px-3 py-2 text-sm cursor-pointer transition-colors",
                    isSelected
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-muted",
                  )}
                  onClick={() => onPick(opt)}
                >
                  <span className="flex items-center gap-2 flex-1 min-w-0">
                    {multiselect && (
                      <Checkbox
                        checked={isSelected}
                        className={cn(
                          "pointer-events-none shrink-0",
                          isSelected && "border-primary-foreground data-[state=checked]:bg-primary-foreground data-[state=checked]:text-primary",
                        )}
                        aria-hidden
                      />
                    )}
                    <span className="truncate">{opt}</span>
                  </span>
                  <div className="flex items-center gap-1 shrink-0">
                    {!multiselect && isSelected && (
                      <Check className="h-4 w-4" />
                    )}
                    <button
                      type="button"
                      aria-label={`Excluir ${opt}`}
                      title={`Excluir ${opt}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onAskDelete(opt);
                      }}
                      className={cn(
                        "h-6 w-6 inline-flex items-center justify-center rounded-md transition-opacity",
                        // Aparece SOMENTE no hover do mouse da linha (group)
                        // — `focus-visible` mantém acessibilidade para Tab keyboard
                        "opacity-0 group-hover:opacity-100 focus-visible:opacity-100",
                        "focus:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                        isSelected
                          ? "hover:bg-primary-foreground/20 text-primary-foreground"
                          : "hover:bg-destructive/10 text-destructive",
                      )}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="px-3 py-6 text-center text-sm text-muted-foreground">
          {searchable && searchValue?.trim() ? "Nenhum resultado" : "Nenhum item cadastrado"}
        </p>
      )}

      <div className="border-t border-border bg-muted/30">
        {creating ? (
          <div className="p-2 space-y-2">
            <div className="flex items-center gap-1.5">
              <Input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={handleDraftKey}
                placeholder="Digite o nome…"
                autoFocus
                className="h-8 text-sm flex-1"
              />
              <Button
                type="button"
                size="sm"
                className="h-8 px-2"
                onClick={onCreateAttempt}
                aria-label="Adicionar"
              >
                <Plus className="h-3.5 w-3.5" />
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0"
                onClick={() => {
                  setCreating(false);
                  setDraft("");
                  onCreateFlagChange?.(false);
                }}
                aria-label="Cancelar"
              >
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>
            {createFlagLabel && (
              <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-2.5 py-1.5">
                <Label className="font-body text-xs cursor-pointer">
                  {createFlagLabel}
                </Label>
                <Switch
                  checked={!!createFlag}
                  onCheckedChange={(v) => onCreateFlagChange?.(v)}
                />
              </div>
            )}
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setCreating(true)}
            className="w-full flex items-center gap-2 px-3 py-2.5 text-sm text-left text-primary font-heading font-semibold hover:bg-primary/10 transition-colors"
          >
            <Plus className="h-4 w-4" />
            {createLabel}
          </button>
        )}
      </div>
    </>
  );
}

/* ─── Trigger compartilhado (visualmente idêntico ao SelectTrigger shadcn) ──
 *
 * IMPORTANTE: precisa usar `forwardRef` porque é renderizado dentro de
 * `<PopoverTrigger asChild>`. Sem forwardRef o Radix não consegue anexar
 * o ref no DOM real, o popover não posiciona/abre corretamente.
 */

const TriggerButton = forwardRef<
  HTMLButtonElement,
  React.ButtonHTMLAttributes<HTMLButtonElement>
>(({ disabled, className, children, ...rest }, ref) => {
  return (
    <button
      ref={ref}
      type="button"
      disabled={disabled}
      className={cn(
        "flex h-10 w-full items-center justify-between rounded-md border border-input bg-background text-foreground px-3 py-2 text-sm",
        "ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
        "disabled:cursor-not-allowed disabled:opacity-50",
        "[&>span]:line-clamp-1",
        className,
      )}
      {...rest}
    >
      {children}
      <ChevronDown className="h-4 w-4 opacity-50 shrink-0 ml-2" />
    </button>
  );
});
TriggerButton.displayName = "EditableSelectTrigger";

/* ─── EditableSelect (single value) ──────────────────────────────────────── */

export function EditableSelect({
  options,
  value,
  onValueChange,
  onCreateOption,
  onDeleteOption,
  placeholder = "Selecione…",
  createLabel = "Criar novo",
  itemLabel = "item",
  disabled,
  className,
  createCase = "preserve",
  searchable,
  createFlagLabel,
}: EditableSelectProps) {
  const [open, setOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState("");
  const [createFlag, setCreateFlag] = useState(false);
  const [search, setSearch] = useState("");
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const handleCreate = () => {
    const raw = draft.trim();
    if (!raw) return;
    const formatted = applyCase(raw, createCase);
    if (options.some((o) => o.toLowerCase() === formatted.toLowerCase())) {
      toast.error(`"${formatted}" já existe na lista.`);
      return;
    }
    onCreateOption(formatted, createFlag);
    onValueChange(formatted);
    setDraft("");
    setCreateFlag(false);
    setCreating(false);
  };

  const handleDelete = () => {
    if (!confirmDelete) return;
    onDeleteOption(confirmDelete);
    if (value === confirmDelete) onValueChange("");
    toast.success(`"${confirmDelete}" removido com sucesso.`);
    setConfirmDelete(null);
  };

  return (
    <>
      <Popover
        open={open}
        onOpenChange={(o) => {
          setOpen(o);
          if (!o) {
            setCreating(false);
            setDraft("");
            setCreateFlag(false);
            setSearch("");
          }
        }}
      >
        <PopoverTrigger asChild>
          <TriggerButton
            disabled={disabled}
            className={className}
            role="combobox"
            aria-expanded={open}
            aria-haspopup="listbox"
          >
            <span className={value ? "" : "text-muted-foreground"}>
              {value || placeholder}
            </span>
          </TriggerButton>
        </PopoverTrigger>
        <PopoverContent
          className="p-0 w-[--radix-popover-trigger-width]"
          align="start"
        >
          <ListBody
            options={options}
            selected={(o) => o === value}
            onPick={(opt) => {
              onValueChange(opt);
              setOpen(false);
            }}
            onAskDelete={setConfirmDelete}
            multiselect={false}
            creating={creating}
            setCreating={setCreating}
            draft={draft}
            setDraft={setDraft}
            onCreateAttempt={handleCreate}
            createLabel={createLabel}
            searchable={searchable}
            searchValue={search}
            onSearchChange={setSearch}
            createFlagLabel={createFlagLabel}
            createFlag={createFlag}
            onCreateFlagChange={setCreateFlag}
          />
        </PopoverContent>
      </Popover>

      <AlertDialog
        open={!!confirmDelete}
        onOpenChange={(o) => { if (!o) setConfirmDelete(null); }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="font-heading">
              Excluir {itemLabel}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir{" "}
              <span className="font-semibold text-foreground">
                "{confirmDelete}"
              </span>{" "}
              da lista de {itemLabel}s? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Não</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Sim, excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

/* ─── EditableMultiSelect (array of values) ──────────────────────────────── */

export function EditableMultiSelect({
  options,
  values,
  onChange,
  onCreateOption,
  onDeleteOption,
  placeholder = "Selecione um ou mais",
  createLabel = "Criar novo",
  itemLabel = "item",
  disabled,
  className,
  createCase = "preserve",
  searchable,
  createFlagLabel,
}: EditableMultiSelectProps) {
  const [open, setOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState("");
  const [createFlag, setCreateFlag] = useState(false);
  const [search, setSearch] = useState("");
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const toggle = (val: string) => {
    if (values.includes(val)) {
      onChange(values.filter((v) => v !== val));
    } else {
      onChange([...values, val]);
    }
  };

  const removeFromTrigger = (val: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onChange(values.filter((v) => v !== val));
  };

  const handleCreate = () => {
    const raw = draft.trim();
    if (!raw) return;
    const formatted = applyCase(raw, createCase);
    if (options.some((o) => o.toLowerCase() === formatted.toLowerCase())) {
      toast.error(`"${formatted}" já existe na lista.`);
      return;
    }
    onCreateOption(formatted, createFlag);
    onChange([...values, formatted]);
    setDraft("");
    setCreateFlag(false);
    setCreating(false);
  };

  const handleDelete = () => {
    if (!confirmDelete) return;
    onDeleteOption(confirmDelete);
    if (values.includes(confirmDelete)) {
      onChange(values.filter((v) => v !== confirmDelete));
    }
    toast.success(`"${confirmDelete}" removido com sucesso.`);
    setConfirmDelete(null);
  };

  return (
    <>
      <Popover
        open={open}
        onOpenChange={(o) => {
          setOpen(o);
          if (!o) {
            setCreating(false);
            setDraft("");
            setCreateFlag(false);
            setSearch("");
          }
        }}
      >
        <PopoverTrigger asChild>
          <TriggerButton
            disabled={disabled}
            className={cn(values.length > 0 && "h-auto min-h-10 py-1.5", className)}
            role="combobox"
            aria-expanded={open}
            aria-haspopup="listbox"
          >
            {values.length === 0 ? (
              <span className="text-muted-foreground">{placeholder}</span>
            ) : (
              <div className="flex flex-wrap items-center gap-1 py-0.5">
                {values.map((v) => (
                  <Badge
                    key={v}
                    variant="secondary"
                    className="font-body text-xs gap-1 pr-1"
                  >
                    {v}
                    <span
                      role="button"
                      tabIndex={-1}
                      onClick={(e) => removeFromTrigger(v, e)}
                      className="rounded-sm hover:bg-muted-foreground/20 px-0.5 cursor-pointer text-muted-foreground hover:text-foreground"
                      aria-label={`Remover ${v}`}
                    >
                      ×
                    </span>
                  </Badge>
                ))}
              </div>
            )}
          </TriggerButton>
        </PopoverTrigger>
        <PopoverContent
          className="p-0 w-[--radix-popover-trigger-width]"
          align="start"
        >
          <ListBody
            options={options}
            selected={(o) => values.includes(o)}
            onPick={toggle}
            onAskDelete={setConfirmDelete}
            multiselect
            creating={creating}
            setCreating={setCreating}
            draft={draft}
            setDraft={setDraft}
            onCreateAttempt={handleCreate}
            createLabel={createLabel}
            searchable={searchable}
            searchValue={search}
            onSearchChange={setSearch}
            createFlagLabel={createFlagLabel}
            createFlag={createFlag}
            onCreateFlagChange={setCreateFlag}
          />
        </PopoverContent>
      </Popover>

      <AlertDialog
        open={!!confirmDelete}
        onOpenChange={(o) => { if (!o) setConfirmDelete(null); }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="font-heading">
              Excluir {itemLabel}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir{" "}
              <span className="font-semibold text-foreground">
                "{confirmDelete}"
              </span>{" "}
              da lista de {itemLabel}s? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Não</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Sim, excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
