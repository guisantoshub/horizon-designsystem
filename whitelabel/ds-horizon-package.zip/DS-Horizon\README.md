# DS-Horizon — Pacote Whitelabel

Pacote de componentes, tokens e configuração do Design System Horizon, pronto
para ser importado em um novo projeto React + Vite + Tailwind e rebrandado
para outra marca.

Leia o **PRD Prompt** (`DS-Horizon-PRD-Prompt.md`, ao lado deste zip na página
"Boas-vindas" do Storybook) para o passo a passo completo de adaptação de
cores, logo e tipografia.

## Conteúdo

```
DS-Horizon/
├── components.json
├── tailwind.config.ts
├── postcss.config.js
└── src/
    ├── index.css                 ← tokens (3 camadas) — ponto central do whitelabel
    ├── lib/utils.ts               ← helper cn()
    ├── hooks/use-mobile.tsx, use-toast.ts
    └── components/
        ├── ui/                    ← ~50 componentes shadcn/ui
        ├── BrandLogo.tsx          ← template de logo (ex-HorizonLogo)
        └── BrandLoadingLogo.tsx   ← template de logo animado de loading
```

## Instalação

1. Copie as pastas acima para a raiz do seu projeto, mesclando com
   `src/` existente.
2. Garanta que o alias `@` aponta para `src/` (`tsconfig.json` e
   `vite.config.ts`):
   ```ts
   resolve: { alias: { "@": path.resolve(__dirname, "./src") } }
   ```
3. Instale as dependências:
   ```bash
   npm install @radix-ui/react-accordion @radix-ui/react-alert-dialog \
     @radix-ui/react-aspect-ratio @radix-ui/react-avatar @radix-ui/react-checkbox \
     @radix-ui/react-collapsible @radix-ui/react-context-menu @radix-ui/react-dialog \
     @radix-ui/react-dropdown-menu @radix-ui/react-hover-card @radix-ui/react-label \
     @radix-ui/react-menubar @radix-ui/react-navigation-menu @radix-ui/react-popover \
     @radix-ui/react-progress @radix-ui/react-radio-group @radix-ui/react-scroll-area \
     @radix-ui/react-select @radix-ui/react-separator @radix-ui/react-slider \
     @radix-ui/react-slot @radix-ui/react-switch @radix-ui/react-tabs \
     @radix-ui/react-toast @radix-ui/react-toggle @radix-ui/react-toggle-group \
     @radix-ui/react-tooltip class-variance-authority clsx cmdk date-fns \
     embla-carousel-react framer-motion input-otp lucide-react next-themes \
     react-day-picker react-hook-form react-resizable-panels recharts sonner \
     tailwind-merge tailwindcss-animate vaul zod @hookform/resolvers
   ```
4. Garanta que `tailwindcss-animate` está nos `plugins` do
   `tailwind.config.ts` e que `darkMode: ["class"]` está configurado.
5. Importe `src/index.css` no entrypoint da aplicação (ex. `main.tsx`).
6. Siga o PRD Prompt para trocar as cores primitivas, a camada HSL e o logo
   pela identidade da nova marca.

## Regra de ouro

Não renomeie variáveis CSS (`--primary`, `--primitive-*`, `--semantic-*`,
`--comp-*`) nem chaves do `tailwind.config.ts`. Troque apenas **valores** e
**assets** — assim todos os componentes continuam funcionando sem edição.
